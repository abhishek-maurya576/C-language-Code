#include<stdio.h>
int main () {
    int i = 0;
    char str[] = "Hii I am teaching you string";
//     while(str[i] != '\0') {
//    // printf("%c",str[i]);
//     i++;
// }
puts(str);
    return 0;
}
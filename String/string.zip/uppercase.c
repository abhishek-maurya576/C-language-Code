#include<stdio.h>
#include<string.h>
int main() {
    char st[] = "abhishek maurya";
    printf("%s",strupr(st));
    return 0;
}
#include<stdio.h>
#include<string.h>
int main() {
    char st[] = "ABCDEFGHIJKLMNOPQRSTUVWSYZ";
    printf("%s",strlwr(st));
    return 0;
}